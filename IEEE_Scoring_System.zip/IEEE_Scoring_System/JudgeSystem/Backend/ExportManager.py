import csv
from GUIs import ErrorPopup
from Backend import Team
from Backend import FinalTeam
from Backend import dbCommands
from operator import itemgetter
from Resources import xlsxwriter as excel
from Resources import xlrd

# Reads data in from an excel spreadsheet
# Done, Works
def ReadFromExcel(filename, type):
    try:
        file = xlrd.open_workbook(filename)
        sheet = file.sheet_by_index(0)
        listOfTeams = []

        # columns list for inital team import

        # columns list for table backup

        # columns list for written report scores format


        # read information into a list of teams based on type of import file
        if type == "2-leg Teams":  # initial data import for 2 leg teams
            row = 1

            while row != sheet.nrows:  # while team number is not empty

                # Gets the team number
                teamNumber = sheet.cell(row, 3).value

                # Gets the team name
                teamName = sheet.cell(row, 7).value.replace("'", "''")

                # Gets the date they compete
                compDay = sheet.cell(row, 9).value.split(' ')[0]
                compDay.strip(",")

                # Gets the control type
                controlType = sheet.cell(row, 4).value.split(' ')[0]
                if controlType == "M":
                    competitionType = "2-leg manual"
                elif controlType == "A":
                    competitionType = "2-leg overall"
                else:
                    competitionType = "2-leg overall"

                # Gets the school
                school = sheet.cell(row, 5).value.replace("'", "''")

                # Generates a team and appends it to the list
                newTeam = Team.Team(str(teamName), str(int(teamNumber)), school, '', '', '', '', '', compDay,
                                    competitionType, '', '', '', '', 0, 0, controlType)
                listOfTeams.append(newTeam)
                row += 1

        elif type == "4-leg Teams":  # initial data import for 4 leg teams
            row = 1

            while row != sheet.nrows:  # while team number is not empty

                # Gets the team number
                teamNumber = sheet.cell(row, 3).value

                # Gets the team name
                teamName = sheet.cell(row, 7).value.replace("'", "''")

                # Gets the date they compete
                compDay = sheet.cell(row, 9).value.split(' ')[0]
                compDay.strip(',')

                # Gets the control type
                controlType = sheet.cell(row, 4).value.split(' ')[0]
                if controlType == "M":
                    competitionType = "4-leg manual"
                elif controlType == "A":
                    competitionType = "4-leg overall"
                else:
                    competitionType = "4-leg overall"

                # Gets the school
                school = sheet.cell(row, 5).value.replace("'", "''")

                # Generates a team and appends it to the list
                newTeam = Team.Team(teamName, str(int(teamNumber)), school, '', '', '', '', '', compDay,
                                    competitionType, '', '', '', '', 0, 0, controlType)
                listOfTeams.append(newTeam)
                row += 1

        elif type.strip() == "Table Backup":  # table backup format - loading in a table backup
            row = 2
            print("TESTING TABLE BACKUP")
            while row != sheet.nrows:  # while team number is not empty
                print("ROW = " + str(row))
                # gets team name [0]
                name = str(sheet.cell(row, 0).value).replace("'", "''")
                # gets team number [1]
                if sheet.cell(row, 1).value != "":
                    number = str(int(sheet.cell(row, 1).value))
                else:
                    return -1
                # gets school [2]
                school = sheet.cell(row, 2).value.replace("'", "''")
                # gets written_report_score [3]
                written_score = str(sheet.cell(row, 3).value)
                # gets control_type [4]
                control = sheet.cell(row, 4).value
                # gets fabrication score [5]
                fabrication = str(sheet.cell(row, 5).value)
                # gets track1 [6]
                track1 = sheet.cell(row, 6).value
                # gets track2 [7]
                track2 = sheet.cell(row, 7).value
                # gets track3 [8]
                track3 = sheet.cell(row, 8).value
                # gets track score [9]
                track_score = sheet.cell(row, 9).value
                # gets compDay [10]
                compDay = sheet.cell(row, 10).value
                # gets comp Type [11]
                compType = sheet.cell(row, 11).value
                # gets oral score [12]
                oral_score = str(sheet.cell(row, 12).value)
                # gets overall score [13]
                total = str(sheet.cell(row, 13).value)
                # gets comments [14]
                comment = sheet.cell(row, 14).value
                # gets display Setting [15]
                display = sheet.cell(row, 15).value
                # gets gets final scores setting [16]
                final_scores = sheet.cell(row, 16).value

                # appends a new team to the list
                print("Adding... " + name)
                newTeam = Team.Team(name, number, school, written_score, track1, track2, track3, track_score, compDay,
                                    compType, oral_score, fabrication, total, comment, display, final_scores, control)
                listOfTeams.append(newTeam)
                row += 1

        else:  # written report scores format - importing written report scores for teams.
            row = 1
            listReport = []
            while row != sheet.nrows:
                # Gets the team number and the written report score.
                number = sheet.cell(row, 1).value
                written_score = sheet.cell(row, 0).value
                listReport.append(str(int(written_score)))
                listReport.append(str(float(number)))
                row += 1
            return listReport

        print("DONE READING FROM FILE")
        return listOfTeams

    except Exception as e:
        print(e)
        return -1


# Function that writes all downloaded data to an Excel file
# DONE
# Keep
def ExportToExcel(AllData, filename, WorkData):

    # Ensures file name has the proper end tag
    if filename.lower().endswith(".xlsx") is False:
        filename += ".xlsx"

    try:
        workbook = excel.Workbook(filename)
        worksheet = workbook.add_worksheet()

        listOfCategories = ["name", "number", "school", "written_report_score", "control_type", "fabrication_score",
                            "track_run_1", "track_run_2", "track_run_3", "track_run", "competition_day", "competition_type",
                            "oral_presentation_score", "overall_score", "comments", "hide_from_display", "hide_from_final_scores"]
        # Writes the titles
        titlething = workbook.add_format()
        titlething.set_text_wrap()
        for i in range(0, len(listOfCategories)):
            worksheet.write(0, i, listOfCategories[i], titlething)

        for row in range(len(AllData)):
            for col in range(len(listOfCategories)):
                worksheet.write(row + 2, col, AllData[row][col])

        workbook.close()

    except Exception as e:
        ErrorPopup.ErrorPopup("001")
        WorkData.systemText.set(e)
        WorkData.displayTimer = 0



# Generates a list of strings that can be used to add data to a new table
# KEEP
# Done
def GenerateStringsReportStyle(filename):

    # Grabs the data from the excel sheet
    rows = ReadFromExcel(filename, "Written Report Score")
    print(rows)
    # Generates the query information
    listOfStrings = []
    for i in range(0, len(rows), 2):
        listOfStrings.append(" SET written_report_score = " + str(rows[i + 1]) + " WHERE number = " + str(rows[i]))
        listOfStrings.append(" SET overall_score = " + str(rows[i + 1]) + " WHERE number = " + str(rows[i]))
    return listOfStrings


# Function to format data for loading in from an autosave or an Export
# Remove
def GenerateListForImportLoad(filename, Data):
    # TODO Add error popup could not find/open file
    # Grabs the data from the file
    try:
        file = open(filename, "r")
        dataDump = file.read()
        file.close()
    except Exception as error:
        ErrorPopup.ErrorPopup("014")
        Data.systemText.set(error)
        Data.displayTimer = 0
        return -1


    # Formats the information into the desired format
    rows = dataDump.split("\n")  # looks like "col1,col2,col3,col4,col5

    # Need the Data to be in this format: [Number, Name, School, WrittenReportScore, TrackRunScore, Time1Min, Time1Sec, Time2Min, Time2Sec,
    # ...Time3Min, Time3Sec, HideScores, HideDisplay, Day, Type, OralScore, Fabrication, Total, Comments, Data]
    formattedRows = []
    for curRow in range(1, len(rows) - 1):

        datapoints = rows[curRow].split(",")

        # Splits the times
        Time1Min = ""
        Time1Sec = ""
        Time2Min = ""
        Time2Sec = ""
        Time3Min = ""
        Time3Sec = ""
        if datapoints[6] != "":
            timeSplit = datapoints[6].split(":")
            Time1Min = timeSplit[0]
            Time1Sec = timeSplit[1]

        if datapoints[7] != "":
            timeSplit = datapoints[7].split(":")
            Time2Min = timeSplit[0]
            Time2Sec = timeSplit[1]

        if datapoints[8] != "":
            timeSplit = datapoints[8].split(":")
            Time3Min = timeSplit[0]
            Time3Sec = timeSplit[1]

        # Generates the list with the inputs in the right order
        newList = [datapoints[1], datapoints[0], datapoints[2], datapoints[3], datapoints[9], Time1Min, Time1Sec, Time2Min, Time2Sec, Time3Min, Time3Sec, datapoints[16],
                   datapoints[15], datapoints[10], datapoints[11], datapoints[12], datapoints[5], datapoints[13], RemoveEndQuotes(datapoints[14]), Data, datapoints[4]]
        formattedRows.append(newList)

    return formattedRows

# Small recursive
# KEEP
def RemoveEndQuotes(s):
    start = 0
    end = len(s) - 1

    # finds the start of the string
    while(s[start]) == '"':
        start += 1

    # finds the end of the string
    while(s[end]) == '"':
        end -= 1

    return s[start:end + 1]


# Determines the placement information for each team
# Returns a list of FinalTeam objects, in no apparent order
# KEEP
def Judge(dataDump, data):
    print("Placing teams")

    # Generates list of final teams without placement information
    listOfTeams = []
    for i in range(len(dataDump)):
        if dataDump[i] != "\n":
            tempTeam = FinalTeam.FinalTeam()
            tempTeam.Populate(dataDump[i])
            listOfTeams.append(tempTeam)


    # Go Through each team and add in the placement values

    place_2manual_saturday = 1
    place_2manual_sunday = 1
    place_2manual_both_days = 1
    place_2overall_saturday = 1
    place_2overall_sunday = 1
    place_2overall_both_days = 1
    place_2total = 1
    place_4manual_saturday = 1
    place_4manual_sunday = 1
    place_4manual_both_days = 1
    place_4overall_saturday = 1
    place_4overall_sunday = 1
    place_4overall_both_days = 1
    place_4total = 1

    for team in listOfTeams:
        # Places 2-leg manual teams
        if team.info["competition_type"].strip(' ') == "2-leg manual":
            if team.info["competition_day"].strip(' ') == "Saturday":
                team.info["place_manual_saturday"] = place_2manual_saturday
                team.info["place_manual_both_days"] = place_2manual_both_days
                team.info["place_overall_saturday"] = place_2overall_saturday
                team.info["place_overall_both_days"] = place_2overall_both_days
                place_2manual_saturday += 1
                place_2manual_both_days += 1
                place_2overall_saturday += 1
                place_2overall_both_days += 1
            elif team.info["competition_day"].strip(' ') == "Sunday":
                team.info["place_manual_sunday"] = place_2manual_sunday
                team.info["place_manual_both_days"] = place_2manual_both_days
                team.info["place_overall_sunday"] = place_2overall_sunday
                team.info["place_overall_both_days"] = place_2overall_both_days
                place_2manual_sunday += 1
                place_2manual_both_days += 1
                place_2overall_sunday += 1
                place_2overall_both_days += 1

        # Places 2-leg overall teams
        elif team.info["competition_type"].strip(' ') == "2-leg overall":
            if team.info["competition_day"].strip(' ') == "Saturday":
                team.info["place_overall_saturday"] = place_2overall_saturday
                team.info["place_overall_both_days"] = place_2overall_both_days
                place_2overall_saturday += 1
                place_2overall_both_days += 1
            elif team.info["competition_day"].strip(' ') == "Sunday":
                team.info["place_overall_sunday"] = place_2overall_sunday
                team.info["place_overall_both_days"] = place_2overall_both_days
                place_2overall_sunday += 1
                place_2overall_both_days += 1

        # Places 4-leg manual teams
        elif team.info["competition_type"].strip(' ') == "4-leg manual":
            if team.info["competition_day"].strip(' ') == "Saturday":
                team.info["place_manual_saturday"] = place_4manual_saturday
                team.info["place_manual_both_days"] = place_4manual_both_days
                team.info["place_overall_saturday"] = place_4overall_saturday
                team.info["place_overall_both_days"] = place_4overall_both_days
                place_4manual_saturday += 1
                place_4manual_both_days += 1
                place_4overall_saturday += 1
                place_4overall_both_days += 1
            elif team.info["competition_day"].strip(' ') == "Sunday":
                team.info["place_manual_sunday"] = place_4manual_sunday
                team.info["place_manual_both_days"] = place_4manual_both_days
                team.info["place_overall_sunday"] = place_4overall_sunday
                team.info["place_overall_both_days"] = place_4overall_both_days
                place_4manual_sunday += 1
                place_4manual_both_days += 1
                place_4overall_sunday += 1
                place_4overall_both_days += 1

        # Places 4-leg overall teams
        elif team.info["competition_type"].strip(' ') == "4-leg overall":
            if team.info["competition_day"].strip(' ') == "Saturday":
                team.info["place_overall_saturday"] = place_4overall_saturday
                team.info["place_overall_both_days"] = place_4overall_both_days
                place_4overall_saturday += 1
                place_4overall_both_days += 1
            elif team.info["competition_day"].strip(' ') == "Sunday":
                team.info["place_overall_sunday"] = place_4overall_sunday
                team.info["place_overall_both_days"] = place_4overall_both_days
                place_4overall_sunday += 1
                place_4overall_both_days += 1

    # Returns the list of teams, sorted and judged
    return listOfTeams


# Returns a list of query strings for each team that is ready for executing
# KEEP
def Finalize(dataDump, data, filename):
    print("Generating SQL Commands")
    listOfTeams = Judge(dataDump, data)


    # Generates the awards printouts
    AwardsPrintout(listOfTeams, filename)
    WebsitePrintout(listOfTeams)



# Generates the awards printout excel sheet
# KEEP
# CHANGE so that it prints by looking for the place_overall instead of sorting it itself
def AwardsPrintout(TeamsList, filename):
    # Ensures file name has the proper end tag
    print(filename.lower().endswith(".xlsx"))
    if filename.lower().endswith(".xlsx") is False:
        filename += ".xlsx"

    filename = "Output Files/" + filename

    print("writing final results to file")
    workbook = excel.Workbook(filename)
    worksheet2leg = workbook.add_worksheet()
    worksheet4leg = workbook.add_worksheet()

    listOfCategories = ["number", "school", "name", "control_type", "place_manual_saturday", "place_manual_sunday", "place_manual_both_days", "place_overall_saturday", "place_overall_sunday", "place_overall_both_days"]

    # Writes the titles
    worksheet2leg.write(0, 0, "2-Leg Placements")
    worksheet4leg.write(0, 0, "4-leg Placements")
    titlething = workbook.add_format()
    titlething.set_text_wrap()
    titles = ["Team #", "School", "Team Name", "Type", "Place # Manual Saturday", "Place # Manual Sunday", "Place # Manual Both Days", "Place # Overall Saturday", "Place # Overall Sunday", "Place # Overall Both Days"]
    for i in range(0, len(titles)):
        worksheet2leg.write(1, i, titles[i], titlething)
        worksheet4leg.write(1, i, titles[i], titlething)

    # Add a bold font capability
    bold = workbook.add_format({'bold': True})
    bold.set_bg_color("99FF33")
    bold.set_border()

    normal = workbook.add_format()
    normal.set_border()

    # Writes team information to the workbook
    leg2index = 2
    leg4index = 2

    for team in TeamsList:
        if team.info["competition_type"].strip(' ') == "2-leg overall" or team.info["competition_type"].strip(' ') == "2-leg manual":
            sheetToUse = worksheet2leg
            legIndex = leg2index
        else:
            sheetToUse = worksheet4leg
            legIndex = leg4index

        for col in range(len(listOfCategories)):
            thingToWrite = team.info[listOfCategories[col]]
            if thingToWrite == "NULL":
                thingToWrite = ""
            elif thingToWrite == ":":
                thingToWrite = ""
            if team.info["competition_day"].strip(' ') == "Saturday" or (col == 4) or (col == 7):
                sheetToUse.write(legIndex, col, thingToWrite, normal)
            else:
                sheetToUse.write(legIndex, col, thingToWrite, bold)

        if team.info["competition_type"].strip(' ') == "2-leg overall" or team.info["competition_type"].strip(' ') == "2-leg manual":
            leg2index += 1
        else:
            leg4index += 1


    workbook.close()


def WebsitePrintout(TeamsList):
    print("writing final results to website file")
    workbook = excel.Workbook("Output Files/WebsiteExcel.xlsx")


    listOfCategories = ["number", "school", "name", "control_type", "written_report_score", "track_run", "oral_presentation_score",
                        "fabrication_score", "overall_score", "track_run_1", "track_run_2", "track_run_3", "competition_day"]

    listOfSheetNames = ["2 Leg Manual Scores", "2 Leg Overall Scores", "4 Leg Manual Scores", "4 Leg Overall Scores"]
    listOfCompetitions = ["2-leg manual", "2-leg overall", "4-leg manual", "4-leg overall"]

    for i in range(len(listOfSheetNames)):
        titleOfSheet = listOfSheetNames[i]
        curCat = listOfCompetitions[i]

        # Creates a new sheet
        worksheet = workbook.add_worksheet()

        # Writes the title information
        titlething = workbook.add_format({'bold': True})
        titlething.set_text_wrap()
        titlething.set_bg_color("#33CCFF")
        titlething.set_border()
        titlething.set_font_size(16)
        worksheet.write(0, 0, titleOfSheet, titlething)
        titles = ["Team #", "School", "Team Name", "Type", "Written Report Score", "Track Run Score", "Oral Pres",
                "Fabrication Score", "Overall Score", "Run Time 1", "Run Time 2", "Run Time 3", "Day"]
        for x in range(0, len(titles)):
            worksheet.write(1, x, titles[x], titlething)

        # Writes the team information
        mainformat = workbook.add_format()
        mainformat.set_text_wrap()
        mainformat.set_border()

        secondaryformat = workbook.add_format({'bold': True})
        secondaryformat.set_text_wrap()
        secondaryformat.set_border()
        
        row = 2
        for team in TeamsList:

            #Determines whether or not to use this team
            reality = False
            if curCat == "2-leg overall" and (team.info["competition_type"].strip(' ') == "2-leg overall" or team.info["competition_type"].strip(' ') == "2-leg manual"):
                reality = True
            elif curCat == "4-leg overall" and (team.info["competition_type"].strip(' ') == "4-leg overall" or team.info["competition_type"].strip(' ') == "4-leg manual"):
                reality = True
            elif curCat == "2-leg manual" and team.info["competition_type"].strip(' ') == "2-leg manual":
                reality = True
            elif curCat == "4-leg manual" and team.info["competition_type"].strip(' ') == "4-leg manual":
                reality = True

            if reality == True:
                for col in range(len(listOfCategories)):
                    thingToWrite = team.info[listOfCategories[col]]
                    if thingToWrite is None or thingToWrite == "NULL" or thingToWrite == ":":
                        thingToWrite = ""
                    elif thingToWrite == "M":
                        thingToWrite = "Manual"
                    elif thingToWrite == "A":
                        thingToWrite = "Auto"
                    elif thingToWrite == "AFB":
                        thingToWrite = "AutoFB"
                    elif dbCommands.is_number(thingToWrite) == True:
                        thingToWrite = thingToWrite
                    elif thingToWrite.strip(' ') == "Saturday":
                        thingToWrite = "Sa"
                    elif thingToWrite.strip(' ') == "Sunday":
                        thingToWrite = "Su"
                    if listOfCategories[col] == "overall_score":
                        worksheet.write(row, col, thingToWrite, secondaryformat)
                    else:
                        worksheet.write(row, col, thingToWrite, mainformat)

                row += 1

    workbook.close()



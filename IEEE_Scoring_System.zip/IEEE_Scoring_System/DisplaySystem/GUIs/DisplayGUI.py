# Main Display GUI function

# from Resources.tkinter import *
#from Backend import DataManager
#from GUIs import SettingsPopup
#from Backend import dbCommands

from Resources.tkinter import *
import Backend.DataManager as DataManager
import GUIs.SettingsPopup as SettingsPopup
import Backend.dbCommands as dbCommands

def Launch(defaultSettings):

    # Initializes Active Data Object to store running information
    data = DataManager.DataManager(defaultSettings)

    # Generates window
    data.window = Tk()
    data.window.title("Display System")

    # Sets full screen and the escape button to remove full screen
    data.window.attributes("-fullscreen", True)

    data.window.bind("<Escape>", lambda x: data.window.attributes("-fullscreen", False))

    data.displayTitle = StringVar()
    data.displayTitle.set("DISPLAY SYSTEM")

    data.windowHeight = data.window.winfo_reqheight()
    data.windowWidth = data.window.winfo_reqwidth() * data.widthMult

    titleLabel = Label(data.window, textvariable=data.displayTitle, font=(data.font, 20))
    titleLabel.grid(row=0, column=0, columnspan=2)

    # Draws the table with the dat in it
    # Resets the tableValues
    data.tableValues = [[StringVar() for i in range(data.width)] for j in range(data.height)]

    # Sets default empty strings to all labels
    for i in range(0, data.height):  # Rows
        for j in range(0, data.width):  # Columns
            data.tableValues[i][j].set("")
    Draw(data)

    # Menu bar along the top
    menubar = Menu(data.window, font=(data.font, data.fontSize))
    menubar.add_command(label="Settings", command=lambda: SettingsPopup.Launch(data, data.root))
    menubar.add_command(label="Disconnect", command=lambda: dbCommands.CloseConnection(data))
    menubar.add_command(label="Switch", command=lambda: dbCommands.CycleThrough(data))
    #menubar.add_command(label="Display Results", command=lambda: dbCommands.SwitchToFinal(data))
    data.window.config(menu=menubar)

    # rebinds the close window option to ensure the server is disconnected
    data.window.protocol('WM_DELETE_WINDOW', lambda: CloseAll(data))

    data.window.mainloop()



# Function that handles exiting using the red X button
# Saves a copy of the database if still connected, then exits the program
# WORKS
def CloseAll(data):
    dbCommands.CloseConnection(data)
    data.window.destroy()
    sys.exit()

def Draw(data):
    print("Drawing...")

    # Determines the widths of each column
    # Gets the longest team name and the longest school name
    teamNameLen = 25
    schoolNameLen = 20
    for row in range(data.height):
        if len(str(data.tableValues[row][1])) > schoolNameLen:  # School, 2 = Team Name
            schoolNameLen = len(str(data.tableValues[row][1]))
        if len(str(data.tableValues[row][2])) > teamNameLen:
            teamNameLen = len(str(data.tableValues[row][2]))
            print(data.tableValues[row][2])

    columnLengths = [8, schoolNameLen, teamNameLen, 8, 13, 11, 11, 13, 15, 12, 12, 12, 5]  # was 31, 30

    # Gets the total number of characters
    sum = 0
    for i in columnLengths:
        sum += i

    for x in range(len(data.colSize)):
        data.colSize[x] = int((columnLengths[x] / sum) * data.windowWidth)

    # Creates Row Frame and the row titles
    if data.titleFrame is not None:
        data.titleFrame.destroy()
    data.titleFrame = Frame(data.window)
    data.titleFrame.grid(row=1, column=0, columnspan=2, sticky=W)
    columnNames = [" Team # ", " School ", " Team Name ", " Type ", " Written Rep ", " Track Run ",
                   " Oral Pres ", " Fabrication ", " Overall Score ", " Run Time 1 ", " Run Time 2 ",
                   " Run Time 3 ", " Day "]
    for titleIndex in range(len(columnNames)):
        box = Label(data.titleFrame, text=("\n" + columnNames[titleIndex] + "\n"), borderwidth=1, relief="solid",
                    width=data.colSize[titleIndex],
                    font=(data.font, data.fontSize), bg="white")
        box.grid(row=0, rowspan=3, column=titleIndex, sticky=N)


    if data.cFrame is not None:
        data.cFrame.destroy()

    # Creates a Frame for the canvas and its scroll bar
    data.cFrame = Frame(data.window, width=data.windowWidth, height=100)
    data.cFrame.grid(row=2, column=0, sticky=N)

    # Creates the Canvas
    data.root = Canvas(data.cFrame, scrollregion=(0, 0, 1500, 800))

    # places a frame inside the canvas
    data.inside = Frame(data.root)
    data.inside.pack(fill="both")



    # Draws the grid in the canvas
    for i in range(data.height):  # Rows
        for j in range(data.width):  # Columns
            box = Label(data.inside, textvariable=data.tableValues[i][j], borderwidth=1, relief="solid",
                        width=data.colSize[j],
                        font=(data.font, data.fontSize), bg="white")
            box.grid(row=i, column=j)

    data.root.pack(side="left", fill="both", expand=True, anchor=N)


# Re-builds the entire window to account for the new infomration
# NOT USED!!
def DrawWinnerWindow(data, newType):
    data.titleFrame.destroy()
    data.titleFrame = Frame(data.window)
    data.titleFrame.grid(row=1, column=0, columnspan=2, sticky=W)
    if newType == "  2-leg  " or newType == "  4-leg  ":
        # Creates Row Frame and the row titles
        for titleIndex in range(len(data.resultsCategories)):
            box = Label(data.titleFrame, text=(data.resultsCategories[titleIndex][0]), borderwidth=1, relief="solid",
                        width=data.resultsCategories[titleIndex][1],
                        font=(data.font, data.fontSize), bg="white")
            box.grid(row=0, rowspan=3, column=titleIndex, sticky=N)
    else:
        columnNames = [" Team # ", " School ", " Team Name ", " Type ", " Written Rep ", " Track Run ",
                       " Oral Pres ", " Fabrication ", " Overall Score ", " Run Time 1 ", " Run Time 2 ",
                       " Run Time 3 ", " Day "]
        for titleIndex in range(len(columnNames)):
            box = Label(data.titleFrame, text=("\n" + columnNames[titleIndex] + "\n"), borderwidth=1, relief="solid",
                        width=data.colSize[titleIndex],
                        font=(data.font, data.fontSize), bg="white")
            box.grid(row=0, rowspan=3, column=titleIndex, sticky=N)

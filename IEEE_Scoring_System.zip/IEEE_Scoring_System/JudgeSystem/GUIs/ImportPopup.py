from Resources.tkinter import *
from Resources.tkinter import filedialog
from Backend import dbCommands


# tkinter function that opens a file browser to locate the desired filepath
def getFile(fileNameBox):
    filename = filedialog.askopenfilename(initialdir="/", title="Select file", filetypes=(("excel files", "*.xlsx"), ("csv files", "*.csv"), ("all files", "*.*")))
    fileNameBox.delete(0, END)
    return filename

def ImportPopup(Data):
    root = Toplevel()
    root.title("Import Data")

    NewTableVal = IntVar()

    NewTableCheck = Checkbutton(root, text=" Create new Table ", variable=NewTableVal, onvalue=1, offvalue=0, font=(Data.font, Data.fontSize))

    # Generates GUI information
    SelectButton = Button(root, text=" Browse ", command=lambda: fileNameBox.insert(0, getFile(fileNameBox)), font=(Data.font, Data.fontSize))
    CancelButton = Button(root, text=" Cancel ", command=root.destroy, font=(Data.font, Data.fontSize))
    ImportButton = Button(root, text=" Import ", command=lambda: dbCommands.ImportData(fileNameBox.get(), Drop.get(), Data, NewTableVal.get()), font=(Data.font, Data.fontSize))
    label1 = Label(root, text="Enter File Name", font=(Data.font, Data.fontSize))
    fileNameBox = Entry(root, width=50, font=(Data.font, Data.fontSize))
    Drop = StringVar(root)
    Drop.set("  Select Data Type  ")  # default value
    DropMenu = OptionMenu(root, Drop, "Written Report Scores", "Table Backup", "2-leg Teams", "4-leg Teams")

    # Draws the GUI
    NewTableCheck.grid(row=0, column=1)
    DropMenu.grid(row=1, column=1)
    label1.grid(row=2, column=0)
    fileNameBox.grid(row=2, column=1)

    SelectButton.grid(row=2, column=2)
    CancelButton.grid(row=3, column=2)
    ImportButton.grid(row=3, column=1)
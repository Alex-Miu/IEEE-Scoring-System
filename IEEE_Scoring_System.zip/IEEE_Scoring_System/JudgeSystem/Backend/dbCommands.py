import Resources.pymysql as mysql
import time

from Backend import ExportManager
from GUIs import ErrorPopup
from GUIs import SettingsGUI
from Resources.tkinter import *


# Small test used by search
# WORKS
def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        pass
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
    return False


# Attempts to connect to and authenticate with the specified Database.
# TODO connect to server then look for databases and either make a new one or connect to the one with the save name
# TODO OR provide a list to the user hand have them choose one to connect to or to make a new one.
# DONE
def Connect(dbName, dbIP, dbUser, dbPass, Data, dbTable, listBox):
    if Data.connected is True:
        ErrorPopup.ErrorPopup("005")
        return -1

    #Saves connection information (but not to file)
    Data.dbName = dbName
    Data.dbIP = dbIP
    Data.dbUser = dbUser
    Data.dbPass = dbPass
    Data.dbTable = "`" + dbTable + "`"

    SettingsGUI.SaveData(Data.dbName, Data.dbIP, Data.dbUser, Data.dbPass, Data, Data.fontSize, Data.dbTable, Data.backup)

    # Attempts to connect to server
    Data.systemText.set("Attempting to connect...")
    Data.displayTimer = 0

    try:
        Data.connection = mysql.connect(dbIP, dbUser, dbPass, dbName)
        Data.connected = True
        UpdateList(Data)
        Data.systemText.set("Connected to " + dbName + " at " + dbIP + " as " + dbUser)
        Data.displayTimer = 0

    except Exception as error:
        ErrorPopup.ErrorPopup("001")
        Data.systemText.set(error)
        Data.displayTimer = 0


# Imports a bunch of data given the format and the file name.
# Format is either for the written report scores or the teams.
# Only imports excel files.
# DONE
def ImportData(filename, dataformat, Data, newTableVal):
    
    # DONE
    newTableName = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    print("============\nNew table:\n")
    print(newTableName)
    print("\n============")
    if "Written Report Scores" in dataformat:
            print(">>>INITIATING IMPORT")
        # Get the formatted information
            listOfStrings = ExportManager.GenerateStringsReportStyle(filename)
            if listOfStrings == -1:
                return -1

            if Data.connected is False:
                ErrorPopup.ErrorPopup("010")
                Data.systemText.set("Failed to import data into database - no connection")
                Data.displayTimer = 0
                return -1

            try:
                print("Building Cursor...")
                # Execute the SQL command
                cursor = Data.connection.cursor()
                for insertCommand in listOfStrings:
                    sql = "UPDATE " + Data.dbTable + insertCommand
                    print(sql)
                    Data.systemText.set(sql)
                    Data.displayTimer = 0

                    cursor.execute(sql)

                # Commits all changes and closes connection
                print("Committing changes...")
                Data.connection.commit()
                cursor.close()

                # Relays success
                Data.systemText.set("Committed imported data to connected table")
                Data.displayTimer = 0
            except Exception as error:
                ErrorPopup.ErrorPopup("011")
                Data.systemText.set(error)
                Data.displayTimer = 0

    # handles new team imports
    elif "2-leg Teams" in dataformat or "4-leg Teams" in dataformat:
            # Get the formatted information
            listOfInfo = ExportManager.ReadFromExcel(filename, dataformat) # TODO keep going
            if listOfInfo == -1:
                return -1

            print("\n>>>INITIATING IMPORT")
            if Data.connected is False:
                ErrorPopup.ErrorPopup("010")
                Data.systemText.set("Failed to import data into database - no connection")
                Data.displayTimer = 0
                return -1

            try:
                # Execute the SQL command
                if newTableVal == 1:
                # Generates a new table TODO check to make sure table doesn't already exist
                    cursor = Data.connection.cursor()
                    sql = "CREATE TABLE `" + newTableName + "` (" + \
                        "`name` varchar(100) NOT NULL, " + \
                        "`number` int(11) NOT NULL, " + \
                        "`school` varchar(100) DEFAULT NULL, " + \
                        "`written_report_score` decimal(7,1) DEFAULT NULL, " + \
                        "`control_type` varchar(20) DEFAULT NULL, " + \
                        "`fabrication_score` int(11) DEFAULT NULL, " + \
                        "`track_run_1` varchar(10) DEFAULT NULL, " + \
                        "`track_run_2` varchar(10) DEFAULT NULL, " + \
                        "`track_run_3` varchar(10) DEFAULT NULL, " + \
                        "`track_run` int(11) DEFAULT NULL, " + \
                        "`competition_day` varchar(45) DEFAULT NULL, " + \
                        "`competition_type` varchar(45) DEFAULT NULL, " + \
                        "`oral_presentation_score` int(11) DEFAULT NULL, " + \
                        "`overall_score` decimal(7,1) DEFAULT NULL, " + \
                        "`comments` varchar(200) DEFAULT NULL, " + \
                        "`hide_from_display` int(11) DEFAULT NULL, " + \
                        "`hide_from_final_scores` int(11) DEFAULT NULL, " + \
                        "PRIMARY KEY (`number`), " + \
                        "UNIQUE KEY `number_UNIQUE` (`number`)) ENGINE=InnoDB DEFAULT CHARSET=utf8"

                    print("Creating new table...")
                    cursor.execute(sql)
                    Data.connection.commit()
                    Data.dbTable = "`" + newTableName + "`"
                    cursor.close()

                    SettingsGUI.SaveData(Data.dbName, Data.dbIP, Data.dbUser, Data.dbPass, Data, Data.fontSize, Data.dbTable, Data.backup)
                for row in listOfInfo:
                    returnVal = AddTeambyTeam(Data, row)
                    if returnVal is -1:
                        #Data.systemText.set("Error occured while adding team")
                        Data.displayTimer = 0
                        return -1

            except Exception as error:
                Data.systemText.set(error)
                ErrorPopup.ErrorPopup("011")
                Data.displayTimer = 0

    # Handles loading in an Excel Save
    # WORKS
    elif "Table Backup" in dataformat:
        # Get the formatted information
        listOfTeams = ExportManager.ReadFromExcel(filename, dataformat)
        if listOfTeams == -1:
            return -1

        if Data.connected is False:
            ErrorPopup.ErrorPopup("010")
            Data.systemText.set("Failed to import data into database - no connection")
            Data.displayTimer = 0
            return -1

        try:
            # Execute the SQL command
            if newTableVal == 1:
                # Generates a new table TODO check to make sure table doesn't already exist
                cursor = Data.connection.cursor()
                sql = "CREATE TABLE `" + newTableName + "` (" + \
                  "`name` varchar(100) NOT NULL, " + \
                  "`number` int(11) NOT NULL, " + \
                  "`school` varchar(100) DEFAULT NULL, " + \
                  "`written_report_score` decimal(7,1) DEFAULT NULL, " + \
                  "`control_type` varchar(20) DEFAULT NULL, " + \
                  "`fabrication_score` int(11) DEFAULT NULL, " + \
                  "`track_run_1` varchar(10) DEFAULT NULL, " + \
                  "`track_run_2` varchar(10) DEFAULT NULL, " + \
                  "`track_run_3` varchar(10) DEFAULT NULL, " + \
                  "`track_run` int(11) DEFAULT NULL, " + \
                  "`competition_day` varchar(45) DEFAULT NULL, " + \
                  "`competition_type` varchar(45) DEFAULT NULL, " + \
                  "`oral_presentation_score` int(11) DEFAULT NULL, " + \
                  "`overall_score` decimal(7,1) DEFAULT NULL, " + \
                  "`comments` varchar(200) DEFAULT NULL, " + \
                  "`hide_from_display` int(11) DEFAULT NULL, " + \
                  "`hide_from_final_scores` int(11) DEFAULT NULL, " + \
                  "PRIMARY KEY (`number`), " + \
                  "UNIQUE KEY `number_UNIQUE` (`number`)) ENGINE=InnoDB DEFAULT CHARSET=utf8"

                cursor.execute(sql)
                Data.connection.commit()
                Data.dbTable = "`" + newTableName + "`"
                cursor.close()
                SettingsGUI.SaveData(Data.dbName, Data.dbIP, Data.dbUser, Data.dbPass, Data, Data.fontSize, Data.dbTable,
                                 Data.backup)
            for team in listOfTeams:
                #TODO add skip if row is empty
                returnVal = AddTeambyTeam(Data, team)
                if returnVal is -1:
                    Data.systemText.set("Error occured while adding team")
                    Data.displayTimer = 0
                    return -1

        except Exception as error:
            ErrorPopup.ErrorPopup("012")
            Data.systemText.set(error)
            Data.displayTimer = 0

    else:
        Data.systemText.set("No option select")
        Data.displayTimer = 0

    UpdateList(Data)


# Exports all data in the database to an excel sheet, with/without hidden ones depending on input
# DONE
def ExportData(filename, WorkData):
    if WorkData.connected is True:
        WorkData.systemText.set("Exporting Data to " + filename)
        WorkData.displayTimer = 0

        sql = "SELECT * FROM " + WorkData.dbTable

        if WorkData.connected is False:
            ErrorPopup.ErrorPopup("010")
            WorkData.systemText.set("Failed to export")
            WorkData.displayTimer = 0
            return -1

        try:
            # Execute the SQL command
            cursor = WorkData.connection.cursor()
            cursor.execute(sql)
            cursor.close()
        except Exception as error:
            ErrorPopup.ErrorPopup("008")
            WorkData.systemText.set(error)
            WorkData.displayTimer = 0
            return -1

        # Collects downloaded data and verifies it isn't empty
        DataDump = cursor.fetchall()
        if DataDump == ():
            ErrorPopup.ErrorPopup("009")
            return -1

        # Organizes Data prior to file-write
        AllData = []
        for i in range(0, len(DataDump)):
            tempList = []
            for x in DataDump[i]:
                if x == ":":
                    tempList.append("")
                else:
                    tempList.append(x)
            AllData.append(tempList)

        # writes to file
        ExportManager.ExportToExcel(AllData, filename, WorkData)


def AddTeambyTeam(Data, team):
    # Checks to make sure team number is unique
    # WORKS
    sql = "SELECT COUNT(*) FROM " + Data.dbTable + " WHERE number = " + team.info["number"]

    try:
        cursor = Data.connection.cursor()
        cursor.execute(sql)
        NumResults = cursor.fetchone()
        cursor.close()
        if NumResults[0] > 0:
            ErrorPopup.ErrorPopup("027")
            Data.systemText.set("Team Number is already in use")
            Data.displayTimer = 0
            return -1
    except Exception as error:
        ErrorPopup.ErrorPopup("006")  # TODO Different Error Code
        Data.systemText.set(error)
        Data.displayTimer = 0
        return -1

    # Verifies that the information provided is of the correct format and is unique
    # Checks for apostrophes in the name and school
    team.info["name"] = team.info["name"].replace("'", "''")
    team.info["school"] = team.info["school"].replace("'", "''")

    # Adds team
    Data.systemText.set("Adding Team... ")
    Data.displayTimer = 0

    # creates a string with the columns of the table
    columns = ""
    for i in range(0, len(Data.CurrentTeam.options)):
        if i != (len(Data.CurrentTeam.options) - 1):
            columns += (Data.CurrentTeam.options[i] + ", ")
        else:
            columns += Data.CurrentTeam.options[i]
    valuesList = [team.info["name"], team.info["number"], team.info["school"], team.info["written_report_score"],
                  team.info["control_type"], team.info["fabrication_score"], team.info["track_run_1"],
                  team.info["track_run_2"], team.info["track_run_3"], team.info["track_run"],
                  team.info["competition_day"], team.info["competition_type"], team.info["oral_presentation_score"],
                  team.info["overall_score"], team.info["comments"], team.info["hide_from_display"],
                  team.info["hide_from_final_scores"]]
    values = ""

    for x in range(0, len(valuesList)):
        if str(valuesList[x]) == "":
            tempvalue = None
        else:
            tempvalue = str(valuesList[x])
        if x != (len(valuesList) - 1):
            if tempvalue is None:
                values += "NULL, "
            elif tempvalue == '':
                values += "NULL, "
            else:
                values += "'" + tempvalue + "', "
        else:
            if tempvalue is None:
                values += "NULL, "
            else:
                values += "'" + tempvalue + "'"

    sql = "INSERT INTO " + Data.dbTable + " (" + columns + ") VALUES (" + values + ")"
    Data.systemText.set(sql)
    Data.displayTimer = 0

    if Data.connected is False:
        ErrorPopup.ErrorPopup("010")
        Data.systemText.set("Failed to add team - no connection with database")
        Data.displayTimer = 0
        return -1

    try:
        # Execute the SQL command
        cursor = Data.connection.cursor()
        cursor.execute(sql)
        Data.connection.commit()
        cursor.close()
        return 1
    except Exception as error:
        ErrorPopup.ErrorPopup("003")
        Data.systemText.set(error)
        Data.displayTimer = 0
        return -1

# Adds a new team from the database
# DONE
def AddTeam(Number, Name, School, WrittenReportScore, TrackRunScore, Time1Min, Time1Sec, Time2Min, Time2Sec,\
            Time3Min, Time3Sec, HideScores, HideDisplay, Day, Type, OralScore, Fabrication, Total, Comments, Data, control_type):

    # Verifies user Input

    # Checks to make sure the Team Number is not null
    if Number == "":
        ErrorPopup.ErrorPopup("025")
        Data.systemText.set("Invalid Name")
        Data.displayTimer = 0
        return -1
    elif is_number(Number) is False:
        ErrorPopup.ErrorPopup("026")
        Data.systemText.set("Invalid Name")
        Data.displayTimer = 0
        return -1

    # Checks to make sure team number is unique
    # WORKS
    sql = "SELECT COUNT(*) FROM " + Data.dbTable + " WHERE number = " + Number

    try:
        cursor = Data.connection.cursor()
        cursor.execute(sql)
        NumResults = cursor.fetchone()
        cursor.close()
        if NumResults[0] > 0:
            ErrorPopup.ErrorPopup("027")
            Data.systemText.set("Team Number is already in use")
            Data.displayTimer = 0
            return -1
    except Exception as error:
        ErrorPopup.ErrorPopup("006")  # TODO Different Error Code
        Data.systemText.set(error)
        Data.displayTimer = 0
        return -1

    # Verifies that the information provided is of the correct format and is unique

    # Checks for apostrophes in the name and school
    Name = Name.replace("'", "''")
    School = School.replace("'", "''")

    # Checks Run Time variables
    varsToCheck = [Time1Min, Time1Sec, Time2Min, Time2Sec, Time3Min, Time3Sec]
    for i in varsToCheck:
        if i != "":
            if is_number(i) is False or len(i) > 2:
                ErrorPopup.ErrorPopup("016")
                Data.systemText.set("Invalid Run time value of: " + str(i))
                Data.displayTimer = 0
                return -1

    # Checks to make sure the scores are numbers
    Total = "0"
    varsScores = [WrittenReportScore, TrackRunScore, OralScore, Fabrication]
    for i in range(len(varsScores)):
        if varsScores[i] != "":
            if is_number(varsScores[i]) is False:
                ErrorPopup.ErrorPopup("0" + str(17 + i))
                Data.systemText.set("Invalid (non-number) input value of: " + str(varsScores[i]))
                Data.displayTimer = 0
                return -1
            else:
                Total = str(float(Total) + float(varsScores[i]))

    # Checks to make sure the competition type and day are not the default value
    if Day == "  Select Day  ":
        ErrorPopup.ErrorPopup("023")
        Data.systemText.set("Invalid selection for Competition Day")
        Data.displayTimer = 0
        return -1

    if Type == "  Select Competition Type  ":
        ErrorPopup.ErrorPopup("024")
        Data.systemText.set("Invalid selection for Competition Type")
        Data.displayTimer = 0
        return -1

    # Checks to make sure control type is accurate
    if control_type == "  Select Control Type  ":
        ErrorPopup.ErrorPopup("030")
        Data.systemText.set("Invalid selection for Control Type")
        Data.displayTimer = 0
        return -1

    Comments = Comments.rstrip()
    Data.systemText.set("Adding Team... ")
    Data.displayTimer = 0
    print("Adding Team")

    # creates a string with the columns of the table
    columns = ""
    for i in range(0, len(Data.CurrentTeam.options)):
        if i != (len(Data.CurrentTeam.options) - 1):
            columns += (Data.CurrentTeam.options[i] + ", ")
        else:
            columns += Data.CurrentTeam.options[i]

    # creates a string with the values for each column
    timeRun1 = Time1Min + ":" + Time1Sec
    timeRun2 = Time2Min + ":" + Time2Sec
    timeRun3 = Time3Min + ":" + Time3Sec
    valuesList = [Name, Number, School, WrittenReportScore, control_type, Fabrication, timeRun1, timeRun2, timeRun3, TrackRunScore, Day, Type, OralScore, Total, Comments, HideDisplay, HideScores]
    values = ""

    for x in range(0, len(valuesList)):
        if str(valuesList[x]) == "":
            tempvalue = None
        else:
            tempvalue = str(valuesList[x])
        if x != (len(valuesList) - 1):
            if tempvalue is None:
                values += "NULL, "
            else:
                values += "'" + tempvalue + "', "
        else:
            if tempvalue is None:
                values += "NULL, "
            else:
                values += "'" + tempvalue + "'"

    sql = "INSERT INTO " + Data.dbTable + " (" + columns + ") VALUES (" + values + ")"
    
    Data.systemText.set(sql)
    Data.displayTimer = 0

    if Data.connected is False:
        ErrorPopup.ErrorPopup("010")
        Data.systemText.set("Failed to add team - no connection with database")
        Data.displayTimer = 0
        return -1

    try:
        # Execute the SQL command
        cursor = Data.connection.cursor()
        cursor.execute(sql)
        Data.connection.commit()
        cursor.close()

        # updates the listbox
        UpdateList(Data)
        return 1
    except Exception as error:
        ErrorPopup.ErrorPopup("003")
        Data.systemText.set(error)
        Data.displayTimer = 0
        return -1

    


# Generates an excel and a text document for the final results
# NOTE - Text document is just a fill-in of pre-designed victory documents.
# Creates a new table in the database that has all of the finalist information
def Finalize(WithSaturday, WithSunday, data, filename):
    print("Finalizing results... ")
    if data.connected is False:
        ErrorPopup.ErrorPopup("010")
        data.systemText.set("Not connected to database")
        data.displayTimer = 0
        return -1

    # Grab all four categories of teams, sorted
    sql = "SELECT * FROM " + data.dbTable + " WHERE hide_from_final_scores = 0 ORDER BY overall_score DESC, track_run DESC, fabrication_score DESC"

    try:
        cursor = data.connection.cursor()
        cursor.execute(sql)
        dataDump = cursor.fetchall()
        cursor.close()

        # Checks to see if the data received is empty
        if dataDump == ():
            ErrorPopup.ErrorPopup("009")
            return -1
    except Exception as error:
        ErrorPopup.ErrorPopup("008")
        data.systemText.set(error)
        data.displayTimer = 0
        return -1

    # 3. Determine the place of each team (for all the extra fields, return as a list of strings for Queries)
    ExportManager.Finalize(dataDump, data, filename)



# Gets the information for one of the teams given a search criteria
# DONE
def Search(value, Data, listOfEntries):
    Data.systemText.set("Gathering information for team: " + str(value))
    Data.displayTimer = 0

    #Gets result back from database

    sql = "SELECT * FROM " + Data.dbTable + " WHERE number = '" + value + "'"

    Data.systemText.set(sql)
    Data.displayTimer = 0

    if Data.connected is False:
        ErrorPopup.ErrorPopup("010")
        Data.systemText.set("Failed to perform search - no connection to database")
        Data.displayTimer = 0
        return -1

    try:
        # Execute the SQL command
        cursor = Data.connection.cursor()
        cursor.execute(sql)
        cursor.close()
    except Exception as error:
        ErrorPopup.ErrorPopup("002")
        Data.systemText.set(error)
        Data.displayTimer = 0
        return -1

    receivedData = cursor.fetchall()
    if receivedData == ():
        ErrorPopup.ErrorPopup("004")
        return -1
    Data.ChangeTeam(Data.CurrentTeam.Translate(receivedData))

    listOfNames = ["school", "name", "written_report_score", "track_run", "comments", "fabrication_score", "oral_presentation_score", "overall_score"]
    for i in range(0, 8):
        item = listOfEntries[i]
        if i != 4:
            if Data.getItem(listOfNames[i]) is None:
                insertString = ""
            else:
                insertString = Data.getItem(listOfNames[i])
            item.delete(0, END)
            item.insert(0, insertString)

    # Changes the data in the Comments Box
    listOfEntries[4].delete("1.0", END)
    if Data.getItem(listOfNames[4]) is None:
        listOfEntries[4].insert("1.0", "")
    else:
        listOfEntries[4].insert("1.0", Data.getItem(listOfNames[4]))

    # Inserts track run time 1
    listOfEntries[8].delete(0, END)
    listOfEntries[9].delete(0, END)
    if Data.getItem("track_run_1") is not None:
        tempList = Data.getItem("track_run_1").split(":")
        listOfEntries[8].insert(0, tempList[0])
        listOfEntries[9].insert(0, tempList[1])

    # sets the run time for 2
    listOfEntries[10].delete(0, END)
    listOfEntries[11].delete(0, END)
    if Data.getItem("track_run_2") is not None:
        tempList = Data.getItem("track_run_2").split(":")
        listOfEntries[10].insert(0, tempList[0])
        listOfEntries[11].insert(0, tempList[1])

    # sets the run time for time 3
    listOfEntries[12].delete(0, END)
    listOfEntries[13].delete(0, END)
    if Data.getItem("track_run_3") is not None:
        tempList = Data.getItem("track_run_3").split(":")
        listOfEntries[12].insert(0, tempList[0])
        listOfEntries[13].insert(0, tempList[1])

    #sets the check boxes
    if Data.getItem("hide_from_display") == 1:
        listOfEntries[14].select()
    else:
        listOfEntries[14].deselect()

    if Data.getItem("hide_from_final_scores") == 1:
        listOfEntries[15].select()
    else:
        listOfEntries[15].deselect()

    # sets the drop down menus
    listOfEntries[16].set(Data.getItem("competition_day"))
    listOfEntries[17].set(Data.getItem("competition_type"))

    # sets the team number
    listOfEntries[18].set("Team Number: " + str(Data.getItem("number")))

    # sets the control type
    listOfEntries[19].set("Control Type: " + str(Data.getItem("control_type")))

    # clears the search box
    Data.searchBox.delete(0, END)


# Updates the listBox with teams in the database every second
# DONE
def UpdateList(Data):
    if Data.connected is True:

        sql = "SELECT name, number FROM " + Data.dbTable + " ORDER BY number"
        
        if Data.connected is False:
            ErrorPopup.ErrorPopup("010")
            Data.systemText.set("failed to update list of teams - no connection to database")
            Data.displayTimer = 0
            return -1

        try:
            cursor = Data.connection.cursor()
            cursor.execute(sql)
            Data.UpdateTeamList(cursor.fetchall(), Data.listBox)
            cursor.close()
        except Exception as e:
            Data.systemText.set(e)
            Data.displayTimer = 0
            ErrorPopup.ErrorPopup("013")


# Disconnects from the database
# DONE
def CloseConnection(Data):
    if Data.connected == True:
        Data.connection.close()
        Data.connection = None
        Data.connected = False
        print("Disconnected")
        Data.systemText.set("Disconnected")
        Data.displayTimer = 0


# Updates the information from a team
# DONE
def Update(Name, School, WrittenReportScore, TrackRunScore, Time1Min, Time1Sec, Time2Min, Time2Sec,\
            Time3Min, Time3Sec, HideScores, HideDisplay, Day, Type, OralScore, Fabrication, Total, Comments, Data, control_type):
    teamNum = Data.CurrentTeam.getItem("number")
    Comments = Comments.rstrip()
    # Updates the Current Team information with the new inputted information

    # updates the listbox
    UpdateList(Data)

    # Checks to make sure the Team name category is not null
    if Name == "":
        ErrorPopup.ErrorPopup("022")
        Data.systemText.set("Invalid Name")
        Data.displayTimer = 0
        return -1

    # Verifies that the information provided is of the correct format and is unique
    # Checks for apostrophes in the name and school
    Name = Name.replace("'", "''")
    School = School.replace("'", "''")

    # Checks Run Time variables
    varsToCheck = [Time1Min, Time1Sec, Time2Min, Time2Sec, Time3Min, Time3Sec]
    for i in varsToCheck:
        if i != "":
            if is_number(i) is False or len(i) > 2:
                ErrorPopup.ErrorPopup("016")
                Data.systemText.set("Invalid Run time value of: " + str(i))
                Data.displayTimer = 0
                return -1

    # Checks to make sure the scores are numbers
    Total = "0"
    varsScores = [WrittenReportScore, TrackRunScore, OralScore, Fabrication]
    for i in range(len(varsScores)):
        if varsScores[i] != "":
            if is_number(varsScores[i]) is False:
                ErrorPopup.ErrorPopup("0" + str(17 + i))
                Data.systemText.set("Invalid (non-number) input value of: " + str(varsScores[i]))
                Data.displayTimer = 0
                return -1
            else:
                Total = str(float(Total) + float(varsScores[i]))

    # calculates the overall score:
    #Total = str(float(WrittenReportScore) + int(TrackRunScore) + int(Fabrication) + int(OralScore))


    # Checks to make sure the competition type and day are not the default value
    if Day == "  Select Day  ":
        ErrorPopup.ErrorPopup("023")
        Data.systemText.set("Invalid selection for Competition Day")
        Data.displayTimer = 0
        return -1

    if Type == "  Select Competition Type  ":
        ErrorPopup.ErrorPopup("024")
        Data.systemText.set("Invalid selection for Competition Type")
        Data.displayTimer = 0
        return -1

    if control_type == "  Select Control Type  ":
        ErrorPopup.ErrorPopup("030")
        Data.systemText.set("Invalid selection for Control Type")
        Data.displayTimer = 0
        return -1


    # creates a string with the values for each column
    timeRun1 = Time1Min + ":" + Time1Sec
    timeRun2 = Time2Min + ":" + Time2Sec
    timeRun3 = Time3Min + ":" + Time3Sec
    valuesList = [Name, teamNum, School, WrittenReportScore, control_type, Fabrication, timeRun1, timeRun2, timeRun3, TrackRunScore,
                  Day, Type, OralScore, Total, Comments, HideDisplay, HideScores]

    for i in range(0, len(Data.CurrentTeam.options)):
        Data.CurrentTeam.info[Data.CurrentTeam.options[i]] = valuesList[i]

    #Constructs the list of terms for the UPDATE query
    values = ""
    for x in range(0, len(valuesList)):
        if str(valuesList[x]) == "":
            dataValue = "NULL"
        else:
            dataValue = "'" + str(valuesList[x]) + "'"

        if x != (len(valuesList) - 1):
            termString = Data.CurrentTeam.options[x] + " = " + dataValue + ", "
        else:
            termString = Data.CurrentTeam.options[x] + " = " + dataValue

        values += termString

    # Updates the information for the current team in the database
    updateCommand = "UPDATE " + Data.dbTable
    conditionsCommand = "SET " + values
    rowLocator = "WHERE number = " + str(teamNum)

    sql = updateCommand + " " + conditionsCommand + " " + rowLocator

    Data.systemText.set("Attempting Update")
    Data.displayTimer = 0

    if Data.connected is False:
        ErrorPopup.ErrorPopup("010")
        Data.systemText.set("failed to update team information - no connection to database")
        Data.displayTimer = 0
        return -1

    try:
        # Execute the SQL command
        cursor = Data.connection.cursor()
        cursor.execute(sql)
        Data.connection.commit()
        cursor.close()
    except Exception as error:
        Data.systemText.set(error)
        Data.displayTimer = 0
        ErrorPopup.ErrorPopup("007")
        return -1

    Data.systemText.set("Successfully updated team information")
    Data.displayTimer = 0

# Gets a list of tables currently in the database
# UNUSED
def GetTables(data):
    sql = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA = '" + data.dbName + "'"

    if data.connected is False:
        ErrorPopup.ErrorPopup("010")
        data.systemText.set("failed to update team information - no connection to database")
        data.displayTimer = 0
        return -1

    try:
        # Execute the SQL command
        cursor = data.connection.cursor()
        cursor.execute(sql)
        cursor.close()
    except Exception as error:
        data.systemText.set(error)
        data.displayTimer = 0
        ErrorPopup.ErrorPopup("000")
        return -1

